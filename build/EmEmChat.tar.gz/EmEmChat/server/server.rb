#!/bin/ruby

EMEMCHAT_ENV = $*[0] || 'package'

require 'ememchat'
EmEmChat.run
