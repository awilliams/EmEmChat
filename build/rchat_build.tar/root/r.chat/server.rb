#!/bin/ruby

RCHAT_ENV = $*[0] || 'package'

require 'rchat'
RChat.run
